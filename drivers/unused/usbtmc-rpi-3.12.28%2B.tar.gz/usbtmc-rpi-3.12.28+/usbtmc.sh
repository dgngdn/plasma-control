#!/bin/sh

/sbin/insmod /lib/modules/3.12.28+/kernel/drivers/usb/class/usbtmc.ko