#!/bin/sh

#copy over the udev rules
cp ./100-usbtmc.rules /etc/udev/rules.d/
chmod 644 /etc/udev/rules.d/100-usbtmc.rules

#copy over the kernel driver
cp ./usbtmc.ko /lib/modules/3.12.28+/kernel/drivers/usb/class/usbtmc.ko
chmod 644 /lib/modules/3.12.28+/kernel/drivers/usb/class/usbtmc.ko

#copy over the script to run when a device is plugged in
#this does the insmod to load the kernel driver
mkdir /usr/local/bin/usbtmc
chmod 775 /usr/local/bin/usbtmc
cp ./usbtmc.sh /usr/local/bin/usbtmc/
chmod 755 /usr/local/bin/usbtmc/usbtmc.sh

#reload the udev rules so that the device is recognized
udevadm control --reload-rules