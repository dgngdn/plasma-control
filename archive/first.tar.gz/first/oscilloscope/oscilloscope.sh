#!/bin/bash

while true; do python scope2.py; sleep 5; done
